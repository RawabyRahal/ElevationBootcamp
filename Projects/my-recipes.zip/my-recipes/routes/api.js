// Import required module
const express = require('express')
const router = express.Router()
const axios = require('axios');

const dairyIngredients = [
    "Cream", "Cheese", "Milk", "Butter", "Creme", "Ricotta", "Mozzarella", "Custard", "Cream Cheese"
]
const glutenIngredients = [
    "Flour", "Bread", "spaghetti", "Biscuits", "Beer"
]
const areaToCountryMapping = {
    'italian': 'Italy',
    'jamaican': 'Jamaica',
    'french': 'France',
    'british': 'United Kingdom',
    'american': 'United States',
    'thai': 'Thailand',
    'irish': 'Ireland',
    'chinese': 'China',
    'mexican': 'Mexico',
    'canadian': 'Canada',
    'indian': 'India',
};

const countryCodes = {
    'italian': 'it',
    'jamaican': 'jm',
    'french': 'fr',
    'british': 'gb',
    'american': 'us',
    'thai': 'th',
    'irish': 'ie',
    'chinese': 'cn',
    'mexican': 'mx',
    'canadian': 'ca',
    'indian': 'in',
};
// const categories = [
//     "Vegetarian", "Chicken", "Miscellaneous", "Beef", "Seafood", "Pork", "Dessert"
// ]

const filterData = (recipes, filteredIngredients) => {
    return recipes.filter(recipe => !recipe.ingredients
        .find(ingredient => filteredIngredients.includes(ingredient)))
}

// const filterRecipesByCategory = (recipes, category) => {
//     return recipes.filter(recipe => recipe.strCategory === category);
// }

const createRecipes = (data) => {

    const dataMap = data.map(item => ({
        idMeal: item.idMeal,
        ingredients: item.ingredients,
        title: item.title,
        thumbnail: item.thumbnail,
        href: item.href,
        category: item.strCategory,
        area: areaToCountryMapping[item.strArea.toLowerCase()],
        countryCode: countryCodes[item.strArea.toLowerCase()]
    }));

    return dataMap
}

// Retrieve data
router.get('/recipes/:ingredient', function (req, res) {
    let ingredient = req.params.ingredient
    let glutenfree = req.query.gluten
    let dairyfree = req.query.dairy
    // let selectedCategory = req.query.category

    axios.get(`https://recipes-goodness-elevation.herokuapp.com/recipes/ingredient/${ingredient}`)
        .then(function (response) {

            let recipes = response.data.results

            // for (let i in recipes) {
            //     console.log(recipes[i].strArea)
            // }

            if (glutenfree == 'true') {
                recipes = filterData(recipes, glutenIngredients)
            }
            if (dairyfree == 'true') {
                recipes = filterData(recipes, dairyIngredients)
            }
            // if (selectedCategory == 'true') {
            //     recipes.filterRecipesByCategory(recipes, categories)
            // }
            console.log("Someone's trying to make a GET request")

            if (response.data.results.length == 0) {
                const error = { error: "try again!" }
                res.status(404).send(error)
            }
            else {
                // console.log(recipes.map(rec => rec.title))
                recipes = createRecipes(recipes)
                // console.log(recipes)
                res.status(200).send(recipes)
            }
        });
})


module.exports = router