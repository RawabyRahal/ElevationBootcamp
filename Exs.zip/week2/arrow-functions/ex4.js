// Create an arrow function that receives three parameters and
//  returns their sum - it should be one line.

const sum = (num1, num2, num3) => console.log("The total is: " + (num1 + num2 + num3))

sum(10, 5, 8)