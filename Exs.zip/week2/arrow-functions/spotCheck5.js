const getFormalTitle = (title , name) =>{
    return title + ' ' + name

}


const formalTitle = getFormalTitle("Madamme", "Lellouche")
console.log(formalTitle) //returns "Maddame Lellouche"