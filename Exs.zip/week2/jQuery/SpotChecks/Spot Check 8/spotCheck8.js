$(".box").hover(function () {
    $(this).css("background-color", "blue")
})