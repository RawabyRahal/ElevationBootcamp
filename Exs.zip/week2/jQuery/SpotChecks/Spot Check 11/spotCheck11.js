//     <div id="bad">Bad Things.</div>

$("#bad").hover(function (){
    $("div").remove("#bad")
})