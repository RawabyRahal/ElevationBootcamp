$("#box").hover(function () {
    // let box1 = $("<div class='box'></div>")
    // let box2 = $("<div class='box'></div>")

    // $("#box").append(box1 , box2)
    // $("#box:first").css("background-color", "purple")
    
    $("#box").css("background-color", "purple")
},function(){
    $("#box").css("background-color", "orange")

})

$("#box2").hover(function () {
    // let box1 = $("<div class='box'></div>")
    // let box2 = $("<div class='box'></div>")

    // $("#box").append(box1 , box2)

    $("#box2").css("background-color", "purple")
},function(){
    $("#box2").css("background-color", "orange")

})