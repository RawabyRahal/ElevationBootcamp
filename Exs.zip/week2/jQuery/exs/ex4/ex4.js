$("div").on("click", function () {
    console.log($("#item").val())
})