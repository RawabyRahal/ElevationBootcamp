
// f1 -> f2 then use callback => f1(f2)

let name="null"

const inn = function (num) {
    name="Rawaby"

  };
setTimeout(inn, 1000)

console.log(name)
  
//   const outer= function(inn,num){
//     inn(10);
//   }
  
  //outer(inn,2000)
 
