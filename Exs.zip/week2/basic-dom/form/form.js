function validation() {
    const name = document.getElementById("name");
    const nameError = document.getElementById("nameError");
    nameError.innerHTML = "";

    const salary = document.getElementById("salary");
    const salaryError = document.getElementById("salaryError");
    salaryError.innerHTML = "";

    const phone = document.getElementById("phone");
    const phoneError = document.getElementById("phoneError");
    phoneError.innerHTML = "";

    const birthday = document.getElementById("birthday");
    const birthdayError = document.getElementById("birthdayError");
    birthdayError.innerHTML = "";


    if (name.value.length == "") {
        nameError.innerHTML = '<div style="margin-left: 20px;"> Empty field!</div>';
    }
    if (name.value.length != "" && name.value.length <= 2) {
        nameError.innerHTML = '<div style="margin-left: 20px;"> your name must be at least 2 characters</div>';
        // return;
    }
    

    if (salary.value.length == "") {
        salaryError.innerHTML = '<div style="margin-left: 20px;"> Empty field!</div>';
    }
    if (salary.value.length != "" && (salary.value < 10000 || salary.value > 16000)) {
        salaryError.innerHTML = '<div style="margin-left: 20px;"> Salary should be between 10,000 and 16,000</div>';
        // return;
    }


    if (birthday.value === "") {
        birthdayError.innerHTML = '<div style="margin-left: 20px;"> Birthday should not be empty</div>';
    }


    if (phone.value.length == "") {
        phoneError.innerHTML = '<div style="margin-left: 20px;"> Empty field!</div>';
    }
    if (phone.value.length != "" && (phone.value < 10)) {
        phoneError.innerHTML = '<div style="margin-left: 20px;"> Phone number should be at least 10 digits</div>';
    }

    if (nameError.innerHTML === "" && salaryError.innerHTML === "" && phoneError.innerHTML === "" && birthdayError.innerHTML === "") {
        alert("Form submitted successfully!");
    }
}
