const reservations = {
  Bob: { claimed: false },
  Ted: { claimed: true }
}


function checkReservation() {
  // const name = prompt('Please enter the name for your reservation');
  const name = document.getElementById("myInput").value
  console.log("$$$$$  " + name)
  let Newname = name
  let lowername = Newname.toLowerCase()
  let keys = Object.keys(reservations)
  for (let key in keys) {
    ``
    if (keys[key].toLowerCase() === lowername) {
      lowername = keys[key]
    }
  }


  if (lowername in reservations) {
    if (reservations[lowername].claimed === false) {
      alert("Welcome " + lowername)
    } else {
      alert('Hmm, someone already claimed this reservation')
    }

  } else {
    alert('You have no reservation')
    reservations[name] = { claimed: true }

  }
}


