// const box = document.getElementById("box")
// box.onclick = function () {
//     box.innerHTML = "clicked"
// }

// box.onmouseenter = function () {
//     box.innerHTML = "Hollaaaa"
// }

/* <div></div> */
const box = document.createElement("div") // dynamically creating an element

/* <div>asdffdfsa</div> */
// box.innerHTML = "asdffdfsa"

/* <div class="box">asdffdfsa</div> */
box.setAttribute("class", "box")

/* <div class="box" onclick=F>asdffdfsa</div> */
box.onclick = function(){       // adding an event to the new element
    box.innerHTML = "I'm alive!"
}

{/* <div id="some-id">
    <div class="box" onclick=F>asdffdfsa</div>
</div>
*/}
document.getElementById("some-id").appendChild(box) // now the box will be on the page, and will react to a click!