const box = document.getElementById("box")

const enterColor = function () {
    box.style.backgroundColor = "#c0392b"
    box.innerHTML = "AHH GO AWAY"
}

const leaveColor = function () {
    box.style.backgroundColor = "#1abc9c"
    box.innerHTML = "Hover over me!"
}


const box2 = document.getElementById("box2")
const clickbtn = function(){
    box2.style.backgroundColor = "#8e44ad"
}