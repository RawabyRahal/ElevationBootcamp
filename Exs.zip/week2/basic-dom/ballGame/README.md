# basic-dom
Create by us to let you play with the DOM.
Play nice.