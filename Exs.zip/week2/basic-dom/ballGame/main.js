// console.log(document)
const header = document.createElement("h1")
header.innerHTML = "The Best Game Ever"
header.setAttribute("class", "header")
document.body.appendChild(header)

const subHeader = document.createElement("h2")
subHeader.innerHTML = "Game by: ~The Creator~"
subHeader.setAttribute("class", "subHeader")
document.body.appendChild(subHeader)


const playingField = document.getElementById("playing-field")

// document.getElementById("down")
const down = document.getElementById("down")
console.log(down)
console.log(playingField.innerHTML)
down.innerHTML = "Down"


document.getElementById("ball").style.backgroundColor = "yellow"

const moveRight = function () {
    let left = parseInt(document.getElementById("ball").style.left) || 0
    left += 15
    document.getElementById("ball").style.left = left + "px"
}

console.log(parseInt("15px")) // prints 15

const moveLeft = function () {
    let right = parseInt(document.getElementById("ball").style.left) || 0
    right -= 15
    document.getElementById("ball").style.left = right + "px"
    console.log("right is : " + right)
}

const moveTop = function () {
    let top = parseInt(document.getElementById("ball").style.top) || 0
    top -= 15
    document.getElementById("ball").style.top = top + "px"
}

const moveDown = function () {
    let down = parseInt(document.getElementById("ball").style.top) || 0
    down += 15
    document.getElementById("ball").style.top = down + "px"
}