// const item = document.getElementById("myList")

const addItem = function () {
    const newItem = document.createElement("li");
    newItem.innerHTML = "A New Item!"
    document.body.appendChild(newItem)
}

// item.onclick = function () {
//     const newItem = document.createElement("li");
//     newItem.innerHTML = "A New Item!"
//     document.body.appendChild(newItem)
// }