
for (let i = 0; i < 15; i++) {
    const box = document.createElement("div")
    box.setAttribute("class", "box")
    document.getElementById("container").appendChild(box)
    box.style.backgroundColor = "#1abc9c"
    box.onmouseleave = function () {

        var colours = ["red",
            "blue",
            "green",
            "lime",
            "teal"]

        var b = Math.floor(Math.random() * colours.length);
        console.log("#### " +b)
        box.style.backgroundColor = colours[b];

    }
}