$('button').on('click', function () {
    alert($("#my-input").val())
})