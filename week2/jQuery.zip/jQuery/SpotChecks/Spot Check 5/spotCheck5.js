const data = $("div").data()

// The item with barcode 311192 will expire on 18-02-2030
console.log("The item with barcode " + data.barcode + "will expire on " + data.expirationdate) 

