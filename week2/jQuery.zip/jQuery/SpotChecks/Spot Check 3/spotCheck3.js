$("#b1").addClass('box')
$("#b2").addClass('box')

$('.box').css('background-color', 'red')

$('#my-input').val('Terabyte')

const color = $("div").data().color  
console.log("the color is: " + color) //prints #2980b9

