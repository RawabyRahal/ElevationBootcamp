// const elem = $("#id")

// const header = $('h1')
// console.log(header)
// console.log("the jQuery  is:" + jQuery)
// console.log("the value of $ is: " + $)


// const myQuery = function (selector) {
//     if (selector[0] == "#") {
//         const elementId = selector.split("#")[1] //will return everything after the # in selector 
//         return document.getElementById(elementId)
//     }
// }

// console.log(myQuery("#newElement"))

$("h4").css("color", "red")

$("h1").css('color', 'blue')
$(".red-div").css('color', 'red')
$("ul li:first").css('color', 'green')
$("ul li:last-child").css('color', 'pink')
$("#brown-div").css('color', 'brown')



